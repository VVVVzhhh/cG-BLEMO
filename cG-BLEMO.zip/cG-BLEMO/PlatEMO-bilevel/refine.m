function Population = refine(Population, Gmax,Global)
    udecs = Population.udecs;
    uDecs = unique(udecs,'rows');
    subPops = cell(size(uDecs,1),1);
    for k =1:size(uDecs,1)
        Lia = ismember(udecs,uDecs(k,:),'rows');
        subPop = Population(Lia);
        
        [subPop,~] = rLLsearch(subPop,Global,Gmax);  
        
        subPops{k} = subPop;        
    end
    candidate = cat(2,subPops{:});
    candidate = candidate(candidate.adds==1);
    [FrontNo,~] = NDSort(candidate.uobjs,[candidate.ucons,candidate.lcons],1);
    
    Population = candidate(FrontNo==1);
    
end


