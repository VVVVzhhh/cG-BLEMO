function [u_Pop,Idx_ul,l_Pop,Arch_partion,RPs,output,Idx_oA,Archive,ORs,TrainSet] = UL_Select_m2m_v21(l_Pop,RPs,output,Archive,ORs,SQ,RQ,W,Global)
%UNTITLED4 此处显示有关此函数的摘要
%   Base on NSGA III

    %% Setting
    Nu = Global.Nu;
    Nl = Global.Nl;
    
    K = size(W,1);
    N   = ceil(Nu/K)*K;
    S   = N/K;
    
    %% Loading
    SP = [l_Pop,SQ];
    R(1,length(SP)*Nl) = INDIVIDUAL;
    TrainSet = R;
    Idx_r = zeros(length(R),1);
    Nr = 0;
    for i = 1:length(SP)        
        R(Nr+1:Nr+sum(SP{i}.adds==1)) = SP{i}(SP{i}.adds==1);
        Idx_r(Nr+1:Nr+sum(SP{i}.adds==1)) = ones(sum(SP{i}.adds==1),1)*i;
        Nr = Nr +sum(SP{i}.adds==1);
                        
        TrainSet((i-1)*Nl+1:i*Nl) = SP{i};
    end
    R(Nr+1:end) = [];
    Idx_r(Nr+1:end) = [];
    
    SR = [RPs,RQ];
   
    A = [Archive,SQ];
    U =[ORs,RQ];
    Au = zeros(length(A),Global.u_D);
    for i = 1:length(A)
        Au(i,:) = A{i}(1).udec;
        
        if i>length(Archive)
            output = [output,A{i}(A{i}.adds==1)];
        end
    end
    %% Update 

     [FrontNo,~] = NDSort(output.uobjs,[output.ucons,output.lcons],1);
      output = output(FrontNo==1);
      if length(output)>Nu*Nl
         Zmin = min(output.uobjs);
         [Z,~]= UniformPoint(Nu*Nl,2);
         [~,I] = max(1-pdist2(output.uobjs-Zmin,Z,'cosine'));
         output = output(I);
      end
      o_udecs = output.udecs;
    
      [~,Loc] = ismember(o_udecs,Au,'rows');
      I = unique(Loc);
      Archive = cell(1,length(I));
      ORs = cell(1,length(I));
      for i = 1:length(I)
          Archive{i} = A{I(i)};
          ORs{i} = U{I(i)};
      end
      [~,Idx_oA] = ismember(Loc,I);
    
    
    [u_Pop,~,Idx_ul,l_Pop,Arch_partion,RPs] = Update_v11(R,Idx_r,SP,SR,W,S);  
   
end

