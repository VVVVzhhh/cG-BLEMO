function [SQ,RQs,l_Pop,RPs,Archive,ORs,TrainSet] = Reproduce_v26p(N,tmax,u_Pop,l_Pop,RPs,Archive,ORs,cgan,Global,TrainSet)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%% setting
%     u_PF = Global.problem.PF(1000);
%     c_PF = [u_PF,zeros(size(u_PF,1),1)];
        
    Nu = Global.Nu;
    Nl = Global.Nl;
    Mu = Global.u_M;
    
    
    r =[];
    r_dc = [];
%% loading data in l_Pop
    l_xu = zeros(Nu,Global.u_D);
    for i = 1:Nu
        l_xu(i,:) = l_Pop{i}(1).udec;
    end
    O_xu = zeros(length(Archive),Global.u_D);
    for i = 1:length(Archive)
        O_xu(i,:) = Archive{i}(1).udec;
    end
    
%% Select the elite UL population from SQ for LL search  through CMOEA\D
    pop = u_Pop;    
    uPop_dc = max(0,0.5 - cgan.Discriminator(pop.udecs,pop.ldecs));
    p_dc = uPop_dc;
    
    r = [];
    r_dc = [];

    %% Generate the weight vectors
%     [ReferencePoints,Nu] = UniformPoint(Nu,Global.u_M,'Latin'); 
%     ReferencePoints = ReferencePoints.*[sqrt(2),1];
%     W = [ReferencePoints(:,1)*cos(pi/4),1-ReferencePoints(:,1)*sin(pi/4),ReferencePoints(:,2)];
    [W,Nu] = UniformPoint(Nu,Mu+1);
   W = W.*[2,2,1];

    T  = 3;
    nr = ceil(Nu/100);
    
    %% Detect the neighbours of each solution
    B = pdist2(W,W);
    [~,B] = sort(B,2);
    B = B(:,1:T);
    
       
     for t=1:tmax
          %% Set the ideal point
        [Zmin0,I1] = min([pop.uobjs,p_dc],[],1);
        Zmax0 = max([pop.uobjs,p_dc],[],1);
%          if tmax>1
            Pu = pop.udecs;
            Pl = pop.ldecs;
%          else
%              Pu = l_xu;
%          end
             
        % For each solution
        for i = 1:Nu

         % Choose the parents
            if   rand < 0.7 
                P = B(i,randperm(size(B,2)));
            else
                P = randperm(Nu);
            end
            
            % Generate an offspring
            if rand<0.5 
%                 Dec = GAhalf([Pu(P(1),:),Pl(P(1),:)],[Pu(P(2),:),Pl(P(2),:)],'bilevel');
%                 Dec = DE([Pu(i,:),Pl(i,:)],[Pu(P(1),:),Pl(P(1),:)],[Pu(P(2),:),Pl(P(2),:)],'bilevel');
%                 u_Dec = Dec(:,1:Global.u_D);
%                 l_Dec = Dec(:,Global.u_D+1:end);

                u_Dec = GAhalf(Pu(P(1),:),Pu(P(2),:),'upper');
                l_Dec = GAhalf(Pl(P(1),:),Pl(P(2),:),'lower');
            else
                u_Dec = GAhalf(Pu(P(1),:),Pu(P(2),:),'upper');
%                 u_Dec = DE(Pu(i,:),Pu(P(1),:),Pu(P(2),:),'upper'); 
                l_Dec = cgan.Generator(u_Dec);
            end       
            Offspring = INDIVIDUAL(u_Dec,l_Dec,'bilevel');
            of_dc = max(0,0.5 - cgan.Discriminator(u_Dec,l_Dec));
            
            if tmax>1
                % Update the ideal point
%                 Zmin([1,2]) = min(Zmin([1,2]),Offspring.uobj);
%                 Zmax([1,2]) = max(Zmax([1,2]),Offspring.uobj);
                [Zmin,I2]= min([Zmin0;Offspring.uobj,of_dc]);
                Zmax= max(Zmax0,[Offspring.uobj,of_dc]);
                scalar = Zmax - Zmin;
                
%                 if length(unique(I2))<2&& ~(unique(I2)<2&&length(unique(I1))>2)
%                     Zmin = Zmin - [0.1*rand(1,Mu),0].*scalar;
%                     scalar = Zmax - Zmin;
%                 end
                
                % Calculate the constraint violation of offspring and P
                CVO = sum(max(0,[Offspring.ucon,Offspring.lcon]));
                CVP = sum(max(0,[pop(P).ucons,pop(P).lcons]),2);
                
                % Update the solutions in P by PBI approach                              
                normW   = sqrt(sum(W(P,:).^2,2));
                normP   = sqrt(sum((([pop(P).uobjs,p_dc(P)]-repmat(Zmin,length(P),1))./scalar).^2,2));
                normO   = sqrt(sum((([Offspring.uobj,of_dc]-Zmin)./scalar).^2,2));
                CosineP = sum((([pop(P).uobjs,p_dc(P)]-repmat(Zmin,length(P),1))./scalar).*W(P,:),2)./normW./normP;
                CosineO = sum((repmat([Offspring.uobj,of_dc]-Zmin,length(P),1)./scalar).*W(P,:),2)./normW./normO;
                g_old   = normP.*CosineP +5*normP.*sqrt(1-CosineP.^2);
                g_new   = normO.*CosineO +5*normO.*sqrt(1-CosineO.^2);
                pop(P(find(g_old>=g_new & CVP==CVO | CVP>CVO,nr))) = Offspring;
                p_dc(P(find(g_old>=g_new & CVP==CVO | CVP>CVO,nr)))= of_dc;
            end
            
            if t>1
                CVR = sum(max(0,[r(P).ucons,r(P).lcons]),2);
                normR   = sqrt(sum((([r(P).uobjs,r_dc(P)]-repmat(Zmin,length(P),1))./scalar).^2,2));
                CosineR = sum((([r(P).uobjs,r_dc(P)]-repmat(Zmin,length(P),1))./scalar).*W(P,:),2)./normW./normR;
                r_old   = normR.*CosineR + 5*normR.*sqrt(1-CosineR.^2);
                r(P(find(r_old>=g_new & CVR==CVO | CVR>CVO,nr))) = Offspring;
                r_dc(P(find(r_old>=g_new & CVR==CVO | CVR>CVO,nr))) = of_dc;
            else
                r = [r,Offspring];
                r_dc = [r_dc;of_dc];
            end
        end
                   
%             if t>1
%                 delete(subplot(2,2,2));
%                 delete(subplot(2,2,4));
%              end  
%             
%              subplot(2,2,2);  
%              Draw(c_PF,'r.');
%              Draw([r.uobjs,r_dc]);
%              
% 
%              subplot(2,2,4);  
%              Draw(u_PF,'r.');
%              Draw(r.uobjs);
%              
%              pause(0.001);
         
     end
%      subplot(2,2,3);  
%      Draw(r.udecs,'b');
%      delete(subplot(2,2,3));
%     
     if tmax>1
         R = [u_Pop,r];
         [FrontNo,~] = NDSort([R.uobjs,[uPop_dc;r_dc]],[R.ucons,R.lcons],inf);
         r_FNo = FrontNo(length(u_Pop)+1:end);
         maxFNo = 1;
         site = r_FNo <= maxFNo;
         if sum(site)<ceil(Nu/2)
             while sum(site)<ceil(Nu/2)
                 maxFNo = maxFNo +1;
                 site = r_FNo <= maxFNo;
             end
             Next = r_FNo < maxFNo;
             Last = find(r_FNo == maxFNo);
             [~,Rank] = sort(r_dc(Last));
             Next(Last(Rank(1:ceil(Nu/2)-sum(Next)))) = true;
         else
             Next = site;
         end
         elite = r(Next);
         
     else
         elite = r;
     end
     
     %% lower-level search
     Qu = elite.udecs;
     qu = unique(Qu,'rows');
     
     SQ = cell(1,size(qu,1));
     RQs= cell(1,size(qu,1));
     for i = 1:size(qu,1)
         [Lia1,Locb1] = ismember(qu(i,:),O_xu,'rows');
         [Lia2,Locb2] = ismember(qu(i,:),l_xu,'rows');
         
         off_C =  elite(sum(Qu-qu(i,:),2)==0);
         if Lia1||Lia2  
            
            if Lia1
                SP = Archive{Locb1};
                RP = ORs{Locb1};
                Archive(Locb1)=[];
                ORs(Locb1) =[];
                O_xu(Locb1,:) =[];
            else
                SP = l_Pop{Locb2};
                RP = RPs{Locb2};
                l_Pop(Locb2)=[];
                RPs(Locb2) =[];
                l_xu(Locb2,:) =[];
            end
            
            R = [SP,off_C,RP(~ismember(RP.ldecs,SP.ldecs,'rows'))];
            [FrontNo,maxFNo] = NDSort(R.lobjs,R.lcons,Nl);
             [~,R] = adds(R,FrontNo');
             
             CrowdDis = CrowdingDistance(R.lobjs,FrontNo);
                 
             Next_SP = FrontNo < maxFNo;
             Last     = find(FrontNo==maxFNo);
             [~,Rank] = sort(CrowdDis(Last),'descend');
             Next_SP(Last(Rank(1:Nl-sum(Next_SP)))) = true;
             RQs{i} = R(Next_SP);
             
             if maxFNo>1                
                 SQ{i} = R(Next_SP);
             else
                 R = R(FrontNo==1);
                 
                 [FrontNo,maxFNo] = NDSort(R.uobjs,R.ucons,Nl);
                 CrowdDis = CrowdingDistance(R.uobjs,FrontNo);
                 Next_SP = FrontNo < maxFNo;
                 Last     = find(FrontNo==maxFNo);
                 [~,Rank] = sort(CrowdDis(Last),'descend');
                 Next_SP(Last(Rank(1:Nl-sum(Next_SP)))) = true;
                 
                 SQ{i} = R(Next_SP);
             end
         else
            if ~isempty(cgan)
                 [SQ{i},RQs{i}] = LLsearch_cgan_v20(N,off_C,cgan,Global);
             else
                 [SQ{i},RQs{i}] = LLsearch_v20(off_C,Global);
            end
            Q = SQ{i};
            TrainSet =[TrainSet,Q(sum(max(0,Q.lcons),2)<=0)];
         if length(TrainSet)>2*Nu*Nl
             TrainSet = TrainSet(length(TrainSet)-2*Nu*Nl+1:end);
         end
         end
     end
          
end



