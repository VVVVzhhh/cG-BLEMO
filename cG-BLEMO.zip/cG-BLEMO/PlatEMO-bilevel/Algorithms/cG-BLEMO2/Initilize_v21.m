function [u_Pop,l_Pop,RPs,Arch_partion,output,Idx_oA,Archive,ORs,W,TrainSet] = Initilize_v21(K,Global)
% Initialize upper level (UL) population and search for their optimal lower level (LL) solutions
%
    %% Setting
    Nu = Global.Nu;
    Nl = Global.Nl;
    u_M = Global.u_M;
    
    [W,K] = UniformPoint(K,u_M);
    N   = ceil(Nl/K)*K;
    S   = N/K;   
    
    %% Initilizing    
    l_Pop = cell(1,Nu);
    RPs = cell(1,Nu); 
    R(1,Nu*Nl) = INDIVIDUAL;
    TrainSet = R;
    Idx_r = zeros(length(R),1);
    Nr = 0;

    Pu = Global.problem.Init(Nu,'upper');    
    % Lower Level (LL) multiobjective optimization run for all xu,i
    for i = 1:Nu
        
        [l_Pop{i},RPs{i}] = LLsearch_v20(Pu(i,:),Global);           %Update SPi to LL Pareto-optimum

        
%         l_PF = Global.problem.lower_PF(Pu(i,:));                  
%         Draw(l_PF,'rs');
%         Draw(Temp_SP{i}.lobjs);

        R(Nr+1:Nr+sum(l_Pop{i}.adds==1)) = l_Pop{i}(l_Pop{i}.adds==1);
        Idx_r(Nr+1:Nr+sum(l_Pop{i}.adds==1)) = ones(sum(l_Pop{i}.adds==1),1)*i;
        Nr = Nr +sum(l_Pop{i}.adds==1);
        
        TrainSet((i-1)*Nl+1:i*Nl) = l_Pop{i};
    end
    R(Nr+1:end) = [];
    Idx_r(Nr+1:end) = [];
    
              
      %% Update 
      [FrontNo,~] = NDSort(R.uobjs,[R.ucons,R.lcons],1);
      output = R(FrontNo==1);
      o_udecs = output.udecs;
    
      [~,Loc] = ismember(o_udecs,Pu,'rows');
      I = unique(Loc);
      Archive = cell(1,length(I));
      ORs = cell(1,length(I));
      for i = 1:length(I)
          Archive{i} = l_Pop{I(i)};
          ORs{i} = RPs{I(i)};
      end
      [~,Idx_oA] = ismember(Loc,I);
      
      
     [u_Pop,~,Idx_ul,l_Pop,Arch_partion,RPs] = Update_v11(R,Idx_r,l_Pop,RPs,W,S);      
     
end